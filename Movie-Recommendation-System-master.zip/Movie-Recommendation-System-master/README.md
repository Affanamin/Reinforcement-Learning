# Movie-Recommendation-System
It is a simple (correlation based) movie recommended system through machine learning.
